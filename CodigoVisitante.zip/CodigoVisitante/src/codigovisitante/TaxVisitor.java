/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigovisitante;

/**
 *
 * Yo
 */
public class TaxVisitor implements Visitor{
    
    private double totalTax; //Impuesto total, guardo el impuesto en totalTax
    
   public void visit(FoodItem item){
        double tax = item.getPrice() * 0.02;  //Saco el valor del impuesto que se realizara a la comida
        totalTax += tax; //Sumo el descuento total
        item.setPrice(item.getPrice()+tax); //Realizo el impuesto de la comida 
    }
        
    public void visit(LiquorItem item){
        double tax = item.getPrice() * 0.1;  //Saco el valor del impuesto que se realizara al licor
        totalTax += tax; //Sumo el descuento total
        item.setPrice(item.getPrice()+tax); //Realizo el impuesto del licor
    }
    
    public double getTotalTax(){  //Getter para devolver el impuesto total
        return totalTax; //retorno el impuesto total
    }
}
