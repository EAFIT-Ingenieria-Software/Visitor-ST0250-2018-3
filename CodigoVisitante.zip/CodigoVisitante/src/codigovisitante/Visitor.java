/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigovisitante;

/**
 *
 * Yo
 */
public interface Visitor {       //Creo una interface llamada Visitor
    void visit(FoodItem item);   //Visito a fooditem y le llevo item
    void visit(LiquorItem item); //Visito a liquoritem y le llevo el item
}
