package codigovisitante;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import codigovisitante.DiscountVisitor;
import codigovisitante.FoodItem;
import codigovisitante.LiquorItem;
import codigovisitante.TaxVisitor;
import codigovisitante.Visitable;
/**
 *
 * 
 */
public class VisitorClient{

    /**
     *
     */
    public static void main(String[] args) {
              
       FoodItem pizza = new FoodItem(1, "Italian pizza", 6.99);
       LiquorItem wine = new LiquorItem(1, "Wine", 10.90);
       FoodItem dog = new FoodItem(1, "Comida para perro", 5.23);
       LiquorItem teq = new LiquorItem(2, "Tequila", 11.23);
       
       DiscountVisitor discount = new DiscountVisitor();
       TaxVisitor tax = new TaxVisitor();
       
       pizza.apply(tax);
       pizza.apply(discount);
       
       System.out.println("Total discount = " + discount.getTotalDiscount());
       System.out.println("taxVisitor =" + tax.getTotalTax());
    }
    
}
