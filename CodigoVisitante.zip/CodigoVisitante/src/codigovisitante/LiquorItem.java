/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigovisitante;

/**
 *
 * 
 */
public class LiquorItem implements Visitable{
    
    public int idLiq;       //Asigno una id para el licor y lo guardo en idLiq
    public String nameLiq;  //Asigno un nombre al licor y lo guardo en nameLiq
    public double priceLiq; //Asigno un precio al licor y lo guardo en priceliq

    public LiquorItem(int idLiq, String nameLiq, double priceLiq) { //Constructor de la clase LiquorItem
        this.idLiq = idLiq;  //Identificacion del licor 
        this.nameLiq = nameLiq; //Nombre del licor
        this.priceLiq = priceLiq; //Precio del licor
    }

    public double getPrice() { //Obtengo el precio del licor con un getter
        return priceLiq; //Lo retorno
    }

    public void setPrice(double priceLiq) {  //Asigno el precio del licor con un setter
        this.priceLiq = priceLiq; //Asigno el precio elegido
    }
    
    @Override //Como voy a sobrecargar el metodo uso Override
    public void apply(Visitor visitor){ //Funcion para aceptar el visitante
        visitor.visit(this); //Acepto el visitante
    }
    
}
