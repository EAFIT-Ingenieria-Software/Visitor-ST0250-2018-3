/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigovisitante;

/**
 *
 * @author juanv
 */
public class FoodItem implements Visitable{
    
    public int idItem;      //Variable global para guardar la id del item
    public String itemName; //Variable global para guardar el nombre del item
    public double priceItem;//Variable global para guardar el precio del item

    public FoodItem(int idItem, String itemName, double priceItem) { //Constructor de la clase FoodItem
        this.idItem = idItem;       //Asigno idItem como idTem
        this.itemName = itemName;   //Asigno itemName como itemName
        this.priceItem = priceItem; //Asigno priceItem como priceItem
    }
    
    public double getPrice(){ //Para obtener el precio creo un getter
        return priceItem; //Retorno el precio del item
    }
    
    public void setPrice(double priceItem){ //Creo un setter para poner el precio del item
        this.priceItem = priceItem; //Asigno el precio deseado
    }
    
    @Override //Afirmo que este metodo se sobrecargara
    public void apply(Visitor visitor){ //Creo una funcion para aceptar al visitante
        visitor.visit(this);//Acepto el visitante
    }
}
