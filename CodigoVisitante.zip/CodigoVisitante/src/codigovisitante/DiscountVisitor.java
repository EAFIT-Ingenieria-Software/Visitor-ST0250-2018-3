/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codigovisitante;

/**
 *
 * Yo
 */
public class DiscountVisitor implements Visitor{
    
    private double totalDiscount; //Variable en la cual guardo el descuento total
    
    public void visit(FoodItem item){
        double discount = item.getPrice() * 0.1;  //Saco el valor del descuento que se realizara a la comida
        totalDiscount += discount; //Sumo el descuento total
        item.setPrice(item.getPrice()-discount); //Realizo el descuento de la comida 
    }
    
    public void visit(LiquorItem item){
        double discount = item.getPrice() * 0.1;  //Saco el valor del descuento que se realizara al licor
        totalDiscount += discount; //Sumo el descuento total
        item.setPrice(item.getPrice()-discount); //Realizo el descuento del licor
    }
    
    public double getTotalDiscount(){ //Getter para devolver de cuanto fue el descuento
        return totalDiscount; //Devuelvo el descuento total
    }
}
